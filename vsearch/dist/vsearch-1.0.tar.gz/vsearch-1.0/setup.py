from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='The Head First Python Search Tools',
    author='cicada',
    author_email='antomylnikov@gmail.com',
    url='no_url.com',
    py_modules=['vsearch'],
)
